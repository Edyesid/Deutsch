package calculadora;

public class Calculator {

	public Calculator () {
	
	}
	
	public void parametros() {
		
		Complex[][] vectorAux = new Complex[][] 
		{{new Complex(0.612372435,0.612372435)},{new Complex(-0.25,0.433012701)}};
		
		ComplexVector vectorAux2 = new ComplexVector(vectorAux);
		
		double norma = vectorAux2.normaVector();
		
		ComplexVector phi = vectorAux2.divisionVectorPorEscalar(norma);
		
		double parametro1 = phi.getVector()[0][0].polar()[0];
		double angulo1 = phi.getVector()[0][0].polar()[1];
		if (angulo1 < 0) {
			angulo1 = angulo1 + 360;
		}
		double parametro12 = phi.getVector()[1][0].polar()[0];
		double angulo2 = phi.getVector()[1][0].polar()[1];
		if (angulo2 < 0) {
			angulo2 = angulo2 + 360;
		}
		double parametro2 = ((angulo2 - angulo1) * Math.PI) / 180;
		
		if (parametro1 == 0.5) {
			System.out.println("Parametro1:"+" pi/3");
		} else if (parametro1 == 0.71) {
			System.out.println("Parametro1:"+" pi/4");
		} else if (parametro1 == 0.87) {
			System.out.println("Parametro1:"+" pi/6");
		}
		
		if (parametro12 == 0.5) {
			System.out.println("Parametro1:"+" pi/6");
		} else if (parametro12 == 0.71) {
			System.out.println("Parametro1:"+" pi/4");
		} else if (parametro12 == 0.87) {
			System.out.println("Parametro1:"+" pi/3");
		} 
		
		System.out.println("Parametro2:" + parametro2);
	}
	/**
	 * Programa de las canicas
	 */
	public void estadoSistema() {
		
		int clicks = 25;
		
		System.out.println("El estado del sistema en " + clicks + " clicks de tiempo es: ");
		
		
		Complex[][] matrizAux = new Complex[][] 
		{{new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
		 {new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)}};
		
		ComplexArray matriz1 = new ComplexArray(matrizAux);
		
		
		Complex[][] vectorAux = new Complex[][] 
		 {{new Complex(10,0)},{new Complex(4,0)},{new Complex(1,0)},{new Complex(7,0)},{new Complex(2,0)},{new Complex(2,0)},{new Complex(11,0)},{new Complex(0,0)},{new Complex(3,0)},{new Complex(1,0)},{new Complex(0,0)},{new Complex(5,0)},{new Complex(2,0)}};
		
		 ComplexArray vector = new ComplexArray(vectorAux);
		
		for(int i = 0; i < clicks; i++) {
			vector = matriz1.arrayMultiplicacion(vector);
		}
		
		if (vector != null) { vector.printArray();}
		
		Complex[][] array = vector.getArray();
		double[] lista = new double[array.length];
		for (int i = 0; i < array.length; i++) {
			lista[i] = array[i][0].getReal();
		}
		
		Grafica grafica = new Grafica(lista);
		grafica.setVisible();
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------
	public void rendijas() {
		
		System.out.println("rendijas: ");
		int rendijas = 2;
		int blancos = 5;
		
		//-------------vector probabilidades------------
		Complex num1 = new Complex(0.2132007169,0.2132007169);
		Complex num2 = new Complex(-0.2132007169,-0.2132007169);
		Complex num3 = new Complex(-0.2132007169,0.2132007169);
		Complex num4 = new Complex(-0.2132007169,-0.2132007169);
		Complex num5 = new Complex(0.2132007169,-0.2132007169);
		Complex num6 = new Complex(-0.2132007169,-0.2132007169);
		Complex num7 = new Complex(-0.2132007169,-0.2132007169);
		Complex num8 = new Complex(-0.2132007169,-0.2132007169);
		Complex num9 = new Complex(0.2132007169,-0.2132007169);
		Complex num10 = new Complex(0.2132007169,-0.2132007169);
		Complex num11 = new Complex(-0.2132007169,0.2132007169);
		
		Complex[][] vectorAux = new Complex[][] {{num1},{num2},{num3},{num4},{num5},{num6},{num7},{num8},{num9},{num10},{num11}};
		
		Complex[][] matriz = new Complex[(2 * blancos + 1) * rendijas][(2 * blancos + 1) * rendijas];
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[0].length; j++) {
				if (matriz[i][j] == null) {
					matriz[i][j] = new Complex(0,0);
				}
			}
		}

		int cont = 1;
		int cont2 = 1;
		for (int x = 0; x < rendijas; x++) {
			for(int z = 0; z < vectorAux.length; z++) {
				matriz[rendijas + cont2 + z][cont] = vectorAux[z][0];
			}
			cont += 1;
			cont2 += blancos + 1;
		}
		
		double num = 1 / Math.pow(rendijas, 0.5);
		
		for (int k = 0; k < rendijas; k++) {
			matriz[1 + k][0] = new Complex(num,0);
		}
		
		ComplexArray matriz1 = new ComplexArray(matriz);
		
		Complex num1d = new Complex(1,0);
		Complex num2d = new Complex(0,0);
		Complex num3d = new Complex(0,0);
		Complex num4d = new Complex(0,0);
		Complex num5d = new Complex(0,0);
		Complex num6d = new Complex(0,0);
		Complex num7d = new Complex(0,0);
		Complex num8d = new Complex(0,0);
		Complex num9d = new Complex(0,0);
		Complex num10d = new Complex(0,0);
		Complex num11d = new Complex(0,0);
		Complex num12d = new Complex(0,0);
		Complex num13d = new Complex(0,0);
		Complex num14d = new Complex(0,0);
		Complex num15d = new Complex(0,0);
		Complex num16d = new Complex(0,0);
		Complex num17d = new Complex(0,0);
		Complex num18d = new Complex(0,0);
		Complex num19d = new Complex(0,0);
		Complex num20d = new Complex(0,0);
		Complex num21d = new Complex(0,0);
		Complex num22d = new Complex(0,0);
		
		Complex[][] vectorInicial = new Complex[][] {{num1d},{num2d},{num3d},{num4d},{num5d},{num6d},{num7d},{num8d},
			{num9d},{num10d},{num11d},{num12d},{num13d},{num14d},{num15d},{num16d},{num17d},{num18d},{num19d},{num20d},{num21d},{num22d}};
		ComplexArray vectorInicial1 = new ComplexArray(vectorInicial);
		
		//matriz1.printArray();
		
		for(int i = 0; i < 2; i++) {
			vectorInicial1 = matriz1.arrayMultiplicacion(vectorInicial1);
		}
		
		ComplexArray vector = new ComplexArray(vectorInicial1.getArray());
		
		if (vector != null) { vector.printArray();}
		
		Complex[][] array = vector.getArray();
		double[] lista = new double[array.length];
		for (int i = 0; i < array.length; i++) {
			lista[i] = array[i][0].moduloCuadrado();
		}
		
		Grafica grafica = new Grafica(lista);
		grafica.setVisible();
		
	}
	
	public void ensamblarSistema() {
		
		int clicks = 5;
		
		System.out.println("el sistema es: ");
		
		//matriz Matriz de la din�mica para el sistema probabil�stico A
		
		Complex num1 = new Complex(0,0);
		Complex num2 = new Complex(0.2,0);
		Complex num3 = new Complex(0.3,0);
		Complex num4 = new Complex(0.5,0);
		Complex num5 = new Complex(0.3,0);
		Complex num6 = new Complex(0.2,0);
		Complex num7 = new Complex(0.1,0);
		Complex num8 = new Complex(0.4,0);
		Complex num9 = new Complex(0.4,0);
		Complex num10 = new Complex(0.3,0);
		Complex num11 = new Complex(0.2,0);
		Complex num12 = new Complex(0.1,0);
		Complex num13 = new Complex(0.3,0);
		Complex num14 = new Complex(0.3,0);
		Complex num15 = new Complex(0.4,0);
		Complex num16 = new Complex(0,0);

		Complex[][] matriz1 = new Complex[][] {{num1,num2,num3,num4},{num5,num6,num7,num8},{num9,num10,num11,num12},{num13,num14,num15,num16}};
		ComplexArray ma = new ComplexArray(matriz1);
		
		//Matriz de la din�mica para el sistema probabil�stico B
		
		Complex num1d = new Complex(0,0);
		Complex num2d = new Complex(0.16666666,0);
		Complex num3d = new Complex(0.83333333,0);
		Complex num4d = new Complex(0.33333333,0);
		Complex num5d = new Complex(0.5,0);
		Complex num6d = new Complex(0.16666666,0);
		Complex num7d = new Complex(0.66666666,0);
		Complex num8d = new Complex(0.33333333,0);
		Complex num9d = new Complex(0,0);
		
		Complex[][] matriz2 = new Complex[][] {{num1d,num2d,num3d},{num4d,num5d,num6d},{num7d,num8d,num9d}};
		ComplexArray mb = new ComplexArray(matriz2);;
		ComplexArray tensor1 = ma.productoTensorial2(mb);
		
		Complex num1e = new Complex(0.2,0);
		Complex num2e = new Complex(0.1,0);
		Complex num3e = new Complex(0.6,0);
		Complex num4e = new Complex(0.1,0);
		
		Complex[][] matriz3 = new Complex[][] {{num1e},{num2e},{num3e},{num4e}};
		ComplexArray va = new ComplexArray(matriz3);
		
		Complex num1f = new Complex(0.7,0);
		Complex num2f = new Complex(0.15,0);
		Complex num3f = new Complex(0.15,0);
		
		Complex[][] matriz4 = new Complex[][] {{num1f},{num2f},{num3f}};
		ComplexArray vb = new ComplexArray(matriz4);
		
		ComplexArray tensor2 = va.productoTensorial2(vb);
		
		ComplexArray vector = new ComplexArray(tensor2.getArray());
		
		for(int i = 0; i < clicks; i++) {
			vector = tensor1.arrayMultiplicacion(vector);
		}
		
		if (vector != null) { vector.printArray();}
		
		Complex[][] array = vector.getArray();
		
		double[] lista2 = new double[array.length];
		for (int i = 0; i < array.length; i++) {
			lista2[i] = array[i][0].getReal();
		}
		
		Grafica grafica = new Grafica(lista2);
		grafica.setVisible();
		
	}
	
	public void posicionParticular() {
		
		Complex[][] vectorAux = new Complex[][] {{new Complex(2,-1)},{new Complex(-1.5,2.5)},{new Complex(-3.5,5)},{new Complex(-4,6)},{new Complex(-3.5,2.5)},{new Complex(0,0)},{new Complex(-3.5,2.5)},{new Complex(6,-4)},{new Complex(0,2.5)},{new Complex(-1,1)}};
		
		ComplexVector vector = new ComplexVector(vectorAux);
		
		double normaCuadrado = Math.pow(vector.normaVector(), 2);
		
		double[] lista = new double[10];
		
		for (int i = 0; i < vectorAux.length; i++) {
			lista[i] = vectorAux[i][0].moduloCuadrado() / normaCuadrado;
		}
		
		Grafica grafica = new Grafica(lista);
		grafica.setVisible();
		
		for (int j = 0; j < 10; j++) {
			System.out.println(lista[j]);
		}
		
  	}
	
	public void CalculadoraEstadisticaParaObservables() {
		
		Complex[][] matrizAux = new Complex[][] 
			{{new Complex(0,0),new Complex(0,-0.5),new Complex(0,-1),new Complex(-3.5,0)},
			{new Complex(0,0.5),new Complex(0,0),new Complex(3.5,0),new Complex(0,-1)},
			{new Complex(0,1),new Complex(3.5,0),new Complex(0,0),new Complex(0,-0.5)},
			{new Complex(-3.5,0),new Complex(0,1),new Complex(0,0.5),new Complex(0,0)}};
			
		ComplexArray omega = new ComplexArray(matrizAux);
		
		Complex[][] vectorAux = new Complex[][] 
		{{new Complex(-2,1)},{new Complex(1,0)},{new Complex(0,-1)},{new Complex(3,2)}};
		
		ComplexVector vectorAux2 = new ComplexVector(vectorAux);
		
		double norma = vectorAux2.normaVector();
		
		ComplexVector phi = vectorAux2.divisionVectorPorEscalar(norma);
		
		ComplexArray accion = omega.accionMatrizSobreVector(phi);
		
		ComplexVector accion2 = new ComplexVector(accion.getArray());
		
		Complex valorEsperado = accion2.produtoInternoDeVectores(phi);
		
		System.out.println("");
		
		System.out.println("el valor esperado es:");
		System.out.println(valorEsperado.getReal());
		
		//---------
		
		Complex[][] identidadAux = new Complex[][] 
				{{new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
				{new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0)},
				{new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0)},
				{new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0)}};
		
		ComplexArray identidad = new ComplexArray(identidadAux);
		
		ComplexArray identidadXvalorEsperado = identidad.vectorEscalar(valorEsperado.multiplicacion(new Complex(-1,0)));
		
		ComplexArray suma = omega.sumArray(identidadXvalorEsperado);
		
		ComplexArray deltaCuadrada = suma.arrayMultiplicacion(suma);
		
		ComplexArray deltaCuadradoPhi = deltaCuadrada.arrayMultiplicacion(new ComplexArray(phi.getVector()));
		
		ComplexArray varianza = deltaCuadradoPhi.arrayAdjunta().arrayMultiplicacion(new ComplexArray(phi.getVector()));
		
		System.out.println("la varianza es");
		System.out.println(varianza.getArray()[0][0].getReal());
	}
	
	public void deutsch() {
		
		/*f(0) = 0, f(1) = 0"*/
		Complex[][] funcion1 = {{new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0)}};
		/*f(0) = 0, f(1) = 1*/	
		Complex[][] funcion2 = {{new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0)}};
		/*f(0) = 1, f(1) = 0*/
							
		Complex[][] funcion3 = {{new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0)}};
		/*f(0) = 1, f(1) = 1*/
		Complex[][] funcion4 = {{new Complex(0,0),new Complex(1,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(1,0),new Complex(0,0),new Complex(0,0),new Complex(0,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(0,0),new Complex(1,0)},
								{new Complex(0,0),new Complex(0,0),new Complex(1,0),new Complex(0,0)}};
		
		Complex[][] hadamard = {{new Complex(0.707106781,0),new Complex(0.707106781,0)},
								{new Complex(0.707106781,0),new Complex(-0.707106781,0)}};
		
		Complex[][] identidad = {{new Complex(1,0),new Complex(0,0)},
								  {new Complex(0,0),new Complex(1,0)}};
		
		Complex[][] ketAux = {{new Complex(1,0)},
							{new Complex(0,0)}};
		
		Complex[][] ketAux1 = {{new Complex(0,0)},
								{new Complex(1,0)}};
		
		ComplexArray u1 = new ComplexArray(funcion1);
		ComplexArray u2 = new ComplexArray(funcion2);
		ComplexArray u3 = new ComplexArray(funcion3);
		ComplexArray u4 = new ComplexArray(funcion4);
		ComplexArray h = new ComplexArray(hadamard);
		ComplexArray i = new ComplexArray(identidad);
		ComplexArray ket1 = new ComplexArray(ketAux);
		ComplexArray ket2 = new ComplexArray(ketAux1);
		
		ComplexArray phi_o = ket1.productoTensorial2(ket2);
		ComplexArray hh = h.productoTensorial2(h);
		ComplexArray phi_1 = hh.accionMatrizSobreVector(new ComplexVector(phi_o.getArray()));
		
		ComplexArray phi_2 = u2.accionMatrizSobreVector(new ComplexVector(phi_1.getArray()));
		ComplexArray hi = h.productoTensorial2(i);
		ComplexArray phi_3 = hi.accionMatrizSobreVector(new ComplexVector(phi_2.getArray()));
		
		double[] lista = new double[phi_3.getArray().length];
		for (int j = 0; j < phi_3.getArray().length; j++) {
			lista[j] = phi_3.getArray()[j][0].moduloCuadrado();
		}
		
		Grafica grafica = new Grafica(lista);
		grafica.setVisible();
		
	}
		
	public static void main(String[] args) {
		Calculator calculo2 = new Calculator();
		//calculo2.estadoSistema();
		//calculo2.rendijas();
		//calculo2.ensamblarSistema();
		//calculo2.posicionParticular();
		//calculo2.CalculadoraEstadisticaParaObservables();
		//calculo2.parametros();
		calculo2.deutsch();
	}
	
	
}